<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php
    $page_title = 'REPORT SKMM';
    require("db_connect.php");
	require("menu.php");
    ?>
  </head>

  <body>     
  <div class="container-fluid">
  <div class="row">
  <div class="col-md-offset-3 main">
  <div class="row placeholders">
  <p>
                 <?php
                if( isset($_POST['view_update']) ): 
                  require("view_update.php");
                endif;
				
				if( isset($_POST['create_pelatih']) ): 
                  require("view_create.php");
                endif;
		
                if( isset($_GET['delete']) && is_numeric($_GET['delete']) ): 
                  require("view_delete.php");
                endif;
                ?>
   <div class="table-responsive">          
  <table width="888" height="47" border="1" align="center" class="table table-bordered table-hover table-striped">
       <tr>
         <td width="250" height="41">Name</td>
         <td width="174">Task</td>
         <td width="253">No Task</td>
         <td width="183" align="center">Action</td>
       </tr>
         <?php
                        // Retrieve list of Album created by this user
                        $query = mysqli_query($GLOBALS['connection'], "SELECT * FROM pelatih") or die(mysqli_error());
                        while( $pelatih = mysqli_fetch_array($query) ):
                        ?>
    <tr>
           <td align="left"><?= $pelatih['name']; ?></td>
           <td><?= $pelatih['task']; ?></td>
           <td><?= $pelatih['no']; ?></td>
           <td align="center"><span class="text-right"><a href="?edit=<?= $pelatih['id']; ?>" class="btn btn-success btn-xs">Kemaskini</a> | <a href="?delete=<?= $pelatih['id']; ?>" class="btn btn-danger btn-xs">Delete</a> </span></td>
         </tr> 
         <?php
                        endwhile;
                        ?>
     </table>
     </div>
  </div>
  </div>
  </div>
    </div>     
    <div class="col-sm-10 col-md-3 sidebar">
         <?php
                    // choose which form to display (ADD or EDIT)
                    
					if( isset($_GET['edit']) && is_numeric($_GET['edit'])):
                        require("view_update_form.php");
				 	else:
					 	require("view_create_form.php");
					endif;
    ?></div>