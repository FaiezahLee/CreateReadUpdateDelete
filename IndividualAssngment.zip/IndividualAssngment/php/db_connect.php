<?php
// Database Details
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", ""); 
define("DB_NAME", "li");

// Establish connection
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die(mysqli_connect_error());

// make it global
$GLOBALS['connection'] = $connection;
?>