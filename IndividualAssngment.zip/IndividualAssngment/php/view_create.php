<?php
require_once("db_connect.php");

// capture submitted values
$name = mysqli_escape_string($GLOBALS['connection'], $_POST['name'] );
$task = mysqli_escape_string($GLOBALS['connection'], $_POST['task'] );
$no = mysqli_escape_string($GLOBALS['connection'], $_POST['no'] );

//insert into table
$saved = mysqli_query($GLOBALS['connection'], "INSERT INTO pelatih VALUES (NULL, '$name', '$task', '$no') ")or die(mysqli_error());

	if($saved):
		echo '<div class="alert alert-success alert-dismissible" role="alert">';
  		echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
  		echo 'User has been added!</div>';
	else:
		echo '<div class="alert alert-danger alert-dismissible" role="alert">';
  		echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
  		echo 'User creation failed!</div>';
	endif;

?>