<h3 class="text-center">CREATE TASK</h3>
<hr>
<center>
<form action=""<?= $_SERVER['PHP_SELF']; ?>" method="POST">
     <table width="888" height="47" border="1" align="center" class="table table-bordered table-hover table-striped">
   <tr>
        <td>Name</td>
        <td><input name="name" type="text" autofocus="autofocus" required class="form-control" size="50"></td>
   </tr>
   <tr>
   <td>Task</td>
    <td><input name="task" type="text" autofocus="autofocus"required class="form-control" size="50"></td>
   </tr> 
   <tr>
        <td>No Task</td>
        <td><input name="no" type="text" autofocus="autofocus" required class="form-control" size="50"></td>
    </tr>
    <tr>
    <td></td>
    <td><button type="submit" name="create_pelatih" class="btn btn-default btn-lg btn-block">Rekod</button></td>
    </table>
</form>
</center>