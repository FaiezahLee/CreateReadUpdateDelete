<?php
require_once("db_connect.php");

// insert into table
$deleted = mysqli_query($GLOBALS['connection'], "DELETE FROM pelatih WHERE id='$_GET[delete]'") or die(mysqli_error());

if($deleted):
    header("Location: create_1.php");
else:
    echo '<div class="alert alert-danger alert-dismissible" role="alert">';
    echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
    echo 'Album deletion failed!</div>';
endif;
?>