<?php
require_once("db_connect.php");

// capture submitted values
$name = mysqli_escape_string($GLOBALS['connection'], $_POST['name'] );
$task = mysqli_escape_string($GLOBALS['connection'], $_POST['task'] );
$no = mysqli_escape_string($GLOBALS['connection'], $_POST['no'] );
$id = mysqli_escape_string($GLOBALS['connection'], $_POST['id'] );
// insert into table
$updated = mysqli_query($GLOBALS['connection'], "UPDATE pelatih SET name='$name', task='$task', no='$no' WHERE id='$id'") or die(mysqli_error());


if($updated):
	echo '<div class="alert alert-success alert-dismissible" role="alert">';
  	echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
  	echo 'Maklumat Berjaya Dikemaskini</div>';
else:
	echo '<div class="alert alert-danger alert-dismissible" role="alert">';
  	echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
  	echo 'User update failed!</div>';
endif;
?>