<?php
$query= mysqli_query($GLOBALS['connection'], "SELECT * FROM pelatih WHERE id = $_GET[edit]") or die(mysqli_error());
$pelatih=mysqli_fetch_array($query);
?>
<h3 class="text-center">Edit Pelatih</h3>
<hr>
<form action="<?= $_SERVER['PHP_SELF']; ?>" method="POST">
   <table>
   <tr>
        <td>Name</td>
        <td><input name="name" type="text" required class="form-control" value="<?= $pelatih['name']; ?>" size="50"></td>
   </tr>
   <tr>
   <td>Task</td>
    <td><input name="task" type="text" required class="form-control" value="<?= $pelatih['task']; ?>" size="50"></td>
   </tr> 
   <tr>
        <td>No</td>
        <td><input name="no" type="text" required class="form-control" value="<?= $pelatih['no']; ?>" size="50"></td>
    </tr>
    <tr><td></td>
    <td><input type="hidden" name="id" value="<?= $pelatih['id']; ?>">
    <button type="submit" name="view_update" class="btn btn-default btn-lg btn-block">Update</button></td></tr>
    </table>
</form>